class NeedForSpeed {
    private int speed;
    private int batteryDrain;
    private int batteryLevel;
    private int distanceDriven;
    NeedForSpeed(int speed, int batteryDrain) {
        this.speed = speed;
        this.batteryDrain = batteryDrain;
        this.batteryLevel = 100;
    }

    public int getDistanceDriven(){
        return distanceDriven;
    }

    public boolean batteryDrained() {
        if(batteryLevel>0){
            return false;
        }
        return true;
    }

    public int distanceDriven() {
        return distanceDriven;
    }

    public void drive() {
        if(batteryDrained()){
            return;
        }
        distanceDriven += speed;
        batteryLevel -= batteryDrain;
    }

    public static NeedForSpeed nitro() {
       return new NeedForSpeed(50,4);
    }
}

class RaceTrack {
    private int distance;
    RaceTrack(int distance) {
        this.distance = distance;
    }

    public boolean tryFinishTrack(NeedForSpeed car) {
        while(car.distanceDriven()<distance){
            if(car.batteryDrained()){
                return false;
            }
            car.drive();
        }
        return true;
    }
}