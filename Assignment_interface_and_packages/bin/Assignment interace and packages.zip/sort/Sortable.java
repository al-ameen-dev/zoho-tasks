package sort;

public interface Sortable {
	
	public void sort(int[] nums);
}
