package library;

import java.time.LocalDateTime;

import library.books.Book;
import library.members.StudentMember;
import library.transactions.Transaction;
import library.members.Member;

public class Main {
	public static void main(String[] args) {
		Book book = new Book(1,"i am legend","ameen",84848484,"thriller","mgrahill");
		Member student = new StudentMember(1,"mark zuckerberg","mark@facebook.com","america");
		Transaction transaction = new Transaction(book, student, LocalDateTime.now());
		System.out.println(transaction);
	}
}
