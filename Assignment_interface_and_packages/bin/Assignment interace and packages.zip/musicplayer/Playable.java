package musicplayer;

public interface Playable {
	void play();
	void pause();
	void stop();
}
