package musicplayer;

public class Main {
	public static void main(String[] args) {
		Playable mp3Player = new Mp3Player();
		Playable streamingPlayer = new StreamingPlayer();
		Playable cdPlayer = new CDPlayer();
		mp3Player.play();
		streamingPlayer.pause();
		cdPlayer.stop();
	}
}
